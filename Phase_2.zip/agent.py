

from __future__ import annotations

import os
from typing import Optional, Tuple

import numpy as np
import torch
import torch.nn as nn



ACTIONS = ["L45", "L22", "FW", "R22", "R45"]
LSTM_DIM = 128
MAX_EP_STEPS = 1000



class RD3QN(nn.Module):
    def __init__(
        self,
        in_dim:    int = 18,
        n_actions: int = 5,
        hidden:    int = 128,
        lstm_dim:  int = 128,
    ):
        super().__init__()
        self.lstm_dim = lstm_dim

        self.encoder = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.LayerNorm(hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.LayerNorm(hidden),
            nn.ReLU(),
        )

        self.lstm = nn.LSTM(hidden, lstm_dim, batch_first=True)

        self.value_head = nn.Sequential(
            nn.Linear(lstm_dim, hidden),
            nn.LayerNorm(hidden),
            nn.ReLU(),
            nn.Linear(hidden, 1),
        )
        self.advantage_head = nn.Sequential(
            nn.Linear(lstm_dim, hidden),
            nn.LayerNorm(hidden),
            nn.ReLU(),
            nn.Linear(hidden, n_actions),
        )

    def forward(
        self,
        x:  torch.Tensor,                                      # (B, T, in_dim)
        hx: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        B, T, _ = x.shape
        enc      = self.encoder(x.view(B * T, -1)).view(B, T, -1)
        out, hx_out = self.lstm(enc, hx)                       # (B, T, lstm_dim)
        V = self.value_head(out)                               # (B, T, 1)
        A = self.advantage_head(out)                           # (B, T, n_actions)
        Q = V + (A - A.mean(dim=-1, keepdim=True))
        return Q, hx_out

    @torch.no_grad()
    def step(
        self,
        obs: torch.Tensor,                                     # (1, 1, in_dim)
        hx:  Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        Q, hx_out = self.forward(obs, hx)
        return Q.squeeze(1), hx_out                            # (1, n_actions), hx




_MODEL: Optional[RD3QN] = None
_hx: Optional[Tuple[torch.Tensor, torch.Tensor]] = None
_step_count: int = 0


def _load_once() -> RD3QN:
    global _MODEL
    if _MODEL is not None:
        return _MODEL

    here = os.path.dirname(os.path.abspath(__file__))
    model_path = os.path.join(here, "weights.pth")

    if not os.path.exists(model_path):
        raise FileNotFoundError(
            f"Model file not found at {model_path}. "
            "Ensure train_r2d2.py has been run and the output file is present."
        )

    model = RD3QN(hidden=128, lstm_dim=LSTM_DIM)
    model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
    model.eval()
    
    _MODEL = model
    return _MODEL


def _reset_hidden_state() -> Tuple[torch.Tensor, torch.Tensor]:
    return (
        torch.zeros(1, 1, LSTM_DIM),
        torch.zeros(1, 1, LSTM_DIM),
    )



def policy(obs: np.ndarray, rng=None) -> str:

    global _hx, _step_count

    model = _load_once()

    if _step_count >= MAX_EP_STEPS or _hx is None:
        _hx = _reset_hidden_state()
        _step_count = 0

    obs_tensor = torch.tensor(obs, dtype=torch.float32).view(1, 1, -1)

    with torch.no_grad():
        q_vals, _hx = model.step(obs_tensor, _hx)

    a_idx = int(q_vals.squeeze(0).argmax())

    _step_count += 1
    return ACTIONS[a_idx]