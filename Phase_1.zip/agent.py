import os

import numpy as np
import torch
import torch.nn as nn

ACTIONS = ["L45", "L22", "FW", "R22", "R45"]


class ResidualBlock(nn.Module):

    def __init__(self, dim: int):
        super().__init__()
        self.block = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
            nn.ReLU(),
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )
        self.act = nn.ReLU()

    def forward(self, x):
        return self.act(x + self.block(x))


class D3QN(nn.Module):
    def __init__(self, in_dim: int = 18, n_actions: int = 5, hidden: int = 128):
        super().__init__()

        self.input_proj = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.LayerNorm(hidden),
            nn.ReLU(),
        )

        self.res_blocks = nn.Sequential(
            ResidualBlock(hidden),
            ResidualBlock(hidden),
        )

        self.value_stream = nn.Sequential(
            nn.Linear(hidden, hidden),
            nn.LayerNorm(hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.LayerNorm(hidden),
            nn.ReLU(),
            nn.Linear(hidden, 1),
        )

        self.advantage_stream = nn.Sequential(
            nn.Linear(hidden, hidden),
            nn.LayerNorm(hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.LayerNorm(hidden),
            nn.ReLU(),
            nn.Linear(hidden, n_actions),
        )

    def forward(self, x):
        feat = self.input_proj(x)
        feat = self.res_blocks(feat)
        V = self.value_stream(feat)
        A = self.advantage_stream(feat)
        return V + (A - A.mean(dim=-1, keepdim=True))


_model = None


def _load_once():
    global _model
    if _model is not None:
        return
    here  = os.path.dirname(os.path.abspath(__file__))
    wpath = os.path.join(here, "weights.pth")
    if not os.path.exists(wpath):
        raise FileNotFoundError(
            "weights.pth not found next to agent.py. "
            "Train offline and include it in the submission zip."
        )
    m  = D3QN()
    sd = torch.load(wpath, map_location="cpu")
    if isinstance(sd, dict) and "state_dict" in sd and isinstance(sd["state_dict"], dict):
        sd = sd["state_dict"]
    m.load_state_dict(sd, strict=True)
    m.eval()
    _model = m


@torch.no_grad()
def policy(obs, rng=None):
    _load_once()

    obs_t  = torch.tensor(np.asarray(obs, dtype=np.float32)).unsqueeze(0)
    q_vals = _model(obs_t).squeeze(0).numpy()
    return ACTIONS[int(np.argmax(q_vals))]