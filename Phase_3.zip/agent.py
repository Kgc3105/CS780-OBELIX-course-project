"""OBELIX Agent — Hybrid DDQN Form (Neural Net 'Eyes' + Heuristic 'Reflexes')

PHASES:
  FIND        : PyTorch DDQN. Explores aggressively with +1 breadcrumbs.
  ESCAPE      : Deterministic 135-Degree Bounce to clear visible AND invisible walls.
  ALIGN       : Deterministic center-lock.
  PUSH        : Deterministic drive to boundary. 
  PUSH_ESCAPE : Deterministic 135-degree shift to diagonally drag the box.
"""

from __future__ import annotations
from typing import Sequence
import os
import random
import numpy as np
from collections import deque

import torch
import torch.nn as nn
import torch.optim as optim

# ══════════════════════════════════════════════════════════════════════════
# HYPERPARAMETERS & CONSTANTS
# ══════════════════════════════════════════════════════════════════════════
ACTIONS: Sequence[str] = ("L45", "L22", "FW", "R22", "R45")
_ACT_IDX = {a: i for i, a in enumerate(ACTIONS)}
_N_ACTS  = len(ACTIONS)

# DDQN Hyperparameters
BATCH_SIZE = 64
LR         = 0.001
GAMMA      = 0.85
EPS        = 0.20  # Constant exploration
TARGET_UPDATE_FREQ = 500  
MEMORY_SIZE = 10000

_WALL_THRESH   = -50   
_ATTACH_THRESH =  100

_LEFT  = (0, 1, 2, 3)
_FRONT = (4, 5, 6, 7, 8, 9, 10, 11)
_RIGHT = (12, 13, 14, 15)
_IR    = 16
_STUCK = 17

_HERE       = os.path.dirname(os.path.abspath(__file__))
_MODEL_PATH = os.path.join(_HERE, "ddqn_model.pth")

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ══════════════════════════════════════════════════════════════════════════
# NEURAL NETWORK & REPLAY BUFFER
# ══════════════════════════════════════════════════════════════════════════
class QNetwork(nn.Module):
    def __init__(self, input_dim=18, output_dim=_N_ACTS):
        super(QNetwork, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, output_dim)
        )

    def forward(self, x):
        return self.net(x)

class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer = deque(maxlen=capacity)
    
    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))
    
    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        return (np.array(states, dtype=np.float32), 
                np.array(actions, dtype=np.int64), 
                np.array(rewards, dtype=np.float32), 
                np.array(next_states, dtype=np.float32), 
                np.array(dones, dtype=np.float32))
    
    def __len__(self):
        return len(self.buffer)

# Global Network Instances
main_net   = QNetwork().to(device)
target_net = QNetwork().to(device)
optimizer  = optim.Adam(main_net.parameters(), lr=LR)
memory     = ReplayBuffer(MEMORY_SIZE)
steps_done = 0

def load_model():
    if os.path.exists(_MODEL_PATH):
        main_net.load_state_dict(torch.load(_MODEL_PATH, map_location=device, weights_only=True))
    target_net.load_state_dict(main_net.state_dict())
    target_net.eval()

def save_model():
    torch.save(main_net.state_dict(), _MODEL_PATH)

def reset_model_weights():
    global main_net, target_net, optimizer, memory, steps_done
    main_net   = QNetwork().to(device)
    target_net = QNetwork().to(device)
    target_net.load_state_dict(main_net.state_dict())
    target_net.eval()
    optimizer  = optim.Adam(main_net.parameters(), lr=LR)
    memory     = ReplayBuffer(MEMORY_SIZE)
    steps_done = 0

load_model()

# ══════════════════════════════════════════════════════════════════════════
# PERSISTENT STATE
# ══════════════════════════════════════════════════════════════════════════
class _S:
    __slots__ = (
        "phase", "escape_queue", "escape_dir", "last_action", 
        "last_raw_obs", "training", "episode"
    )

    def reset(self):
        self.phase        = "find"
        self.escape_queue = []
        self.escape_dir   = "L45"
        self.last_action  = "FW"
        self.last_raw_obs = None

    def new_episode(self, training: bool):
        self.reset()
        self.training = training
        if training: self.episode += 1

_st = _S()
_st.training = True
_st.episode  = 0
_st.reset()

def reset_agent(training: bool = True): 
    _st.new_episode(training)

def _is_front_dominant(obs: np.ndarray) -> bool:
    lsum = sum(float(obs[i]) for i in _LEFT)
    fsum = sum(float(obs[i]) for i in _FRONT)
    rsum = sum(float(obs[i]) for i in _RIGHT)
    return fsum > 0 and fsum >= lsum and fsum >= rsum

# ══════════════════════════════════════════════════════════════════════════
# MAIN POLICY (Hybrid Execution)
# ══════════════════════════════════════════════════════════════════════════
def policy(obs: np.ndarray, rng: np.random.Generator, reward: float = 0.0) -> str:
    global steps_done

    ir    = bool(obs[_IR])
    any_s = any(obs[i] for i in range(16))
    lsum  = sum(float(obs[i]) for i in _LEFT)
    fsum  = sum(float(obs[i]) for i in _FRONT)
    rsum  = sum(float(obs[i]) for i in _RIGHT)
    stuck = bool(obs[_STUCK])

    # Recover the true reward to check for attachment
    base_reward = reward + (200.0 if stuck else 0.0)

    # ── Phase transition: Attach ───
    if base_reward >= 90 and _st.phase in ("find", "escape"):
        _st.phase        = "align"
        _st.escape_queue = []

    # ══════════════════════════════════════════════════════════════════════
    # HEURISTIC REFLEXES: UNIVERSAL CRASH FAILSAFE
    # ══════════════════════════════════════════════════════════════════════
    if stuck and _st.last_action == "FW" and _st.phase in ("find", "align", "push"):
        if _st.phase == "find":
            _st.phase = "escape"
            # Hard 135-degree bounce to guarantee clearance of invisible boundaries
            if lsum > rsum: 
                _st.escape_queue = ["R45", "R45", "R45", "FW", "FW"]
            else: 
                _st.escape_queue = ["L45", "L45", "L45", "FW", "FW"]
                
        elif _st.phase in ("align", "push"):
            _st.phase = "push_escape"
            if lsum > rsum: 
                _st.escape_queue = ["R45", "R45", "R45", "FW", "FW", "FW", "L45", "L45", "L45"]
            else: 
                _st.escape_queue = ["L45", "L45", "L45", "FW", "FW", "FW", "R45", "R45", "R45"]

    # ══════════════════════════════════════════════════════════════════════
    # HEURISTIC REFLEXES: ALIGN & PUSH
    # ══════════════════════════════════════════════════════════════════════
    if _st.phase == "align":
        if ir and _is_front_dominant(obs):
            _st.phase = "push"
            _st.last_action = "FW"
            return "FW"
        action = "L22" if lsum >= rsum else "R22" if ir else "L45" if lsum >= rsum else "R45"
        _st.last_action = action
        return action

    if _st.phase == "push":
        if not ir:
            _st.phase = "align"
            action = "L45" if lsum >= rsum else "R45"
            _st.last_action = action
            return action
        _st.last_action = "FW"
        return "FW"
            
    if _st.phase == "push_escape":
        if _st.escape_queue:
            action = _st.escape_queue.pop(0)
            _st.last_action = action
            return action
        else:
            _st.phase = "align"
            action = "L45" if lsum >= rsum else "R45" 
            _st.last_action = action
            return action

    # ══════════════════════════════════════════════════════════════════════
    # HEURISTIC REFLEXES: ESCAPE EXECUTION
    # ══════════════════════════════════════════════════════════════════════
    if _st.phase == "escape":
        if _st.escape_queue:
            action = _st.escape_queue.pop(0)
            _st.last_action = action
            return action
        else:
            # The queue is empty, meaning we have physically turned our back 
            # to the boundary and stepped away. Safe to hand control back to DDQN.
            _st.phase = "find"
            # Do NOT return here. Let the code fall through to the DDQN block below 

    # ══════════════════════════════════════════════════════════════════════
    # DDQN CONTROL: FIND PHASE (The Neural Net "Eyes")
    # ══════════════════════════════════════════════════════════════════════
    if _st.phase == "find":
        
        # 1. Store the Experience in the Replay Buffer
        if _st.training and _st.last_raw_obs is not None:
            done = float(reward >= 1999) 
            
            # ─── REVISED REWARD SHAPING (Curing the Cowardly Agent) ───
            shaped_r = 0.0
            
            if any_s and fsum <= 2: 
                shaped_r = 20.0   # MASSIVE reward for tracking the box
            elif fsum > 2 and _st.last_action == "FW": 
                shaped_r = -10.0  # Mild slap on the wrist for driving into a wall
            elif _st.last_action != "FW": 
                shaped_r = -2.0   # Harsher penalty to explicitly stop it from spinning
            else:
                shaped_r = 1.0    # Positive "breadcrumb" reward for driving FW safely

            memory.push(_st.last_raw_obs, _ACT_IDX[_st.last_action], shaped_r, obs, done)

        _st.last_raw_obs = obs.copy() 

        # 2. Select Action (Epsilon-Greedy with DDQN)
        if _st.training and rng.random() < EPS:
            act_idx = int(rng.choice(_N_ACTS))
        else:
            with torch.no_grad():
                obs_tensor = torch.FloatTensor(obs).unsqueeze(0).to(device)
                q_values = main_net(obs_tensor)
                act_idx = int(torch.argmax(q_values).item())
                
        action = ACTIONS[act_idx]
        _st.last_action = action

        # 3. Train the Neural Network (Batch Experience Replay)
        if _st.training and len(memory) > BATCH_SIZE:
            
            states, actions, rewards, next_states, dones = memory.sample(BATCH_SIZE)
            
            states = torch.FloatTensor(states).to(device)
            actions = torch.LongTensor(actions).unsqueeze(1).to(device)
            rewards = torch.FloatTensor(rewards).unsqueeze(1).to(device)
            next_states = torch.FloatTensor(next_states).to(device)
            dones = torch.FloatTensor(dones).unsqueeze(1).to(device)

            # Get current Q values
            current_q = main_net(states).gather(1, actions)
            
            # Double DQN Logic
            with torch.no_grad():
                next_actions = main_net(next_states).argmax(1, keepdim=True)
                next_q = target_net(next_states).gather(1, next_actions)
                target_q = rewards + (GAMMA * next_q * (1 - dones))

            # Optimize
            loss = nn.MSELoss()(current_q, target_q)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # Sync Target Network
            steps_done += 1
            if steps_done % TARGET_UPDATE_FREQ == 0:
                target_net.load_state_dict(main_net.state_dict())

        return action